from typing import Tuple
from abc import ABC, abstractmethod

import numpy as np


class MarkerIdentifier(ABC):

    @abstractmethod
    def identify_marker(self, gray_image, marker_points) -> Tuple[bool, int, np.array]:
        """
        Identify a marker based on the inner pixel values

        :param gray_image: The original gray scale image
        :param marker_points: The marker edge points in the image
        :return: A tuple of:
                 - A boolean indicating whether the marker could
                   be successfully identified
                 - The ID of the marker. None if the identification failed
                 - The corrected marker points (rotated to fit the marker
                   orientation). The marker points are only modified if
                   the identification was successful.
        """
