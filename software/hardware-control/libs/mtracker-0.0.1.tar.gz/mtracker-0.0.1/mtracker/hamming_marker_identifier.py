import sys
import logging
from typing import Iterable, Tuple

import cv2
import numpy as np

from .hamming_codes import HammingCodes


class HammingMarkerIdentifier:
    """
    Identifies a marker based on the inner pixel values
    """

    logger = logging.getLogger(__module__)

    def __init__(self, marker_matrix_size: Tuple[int, int] = (6, 6),
                 scale: int = 6, marker_ids: Iterable[int] = (),
                 color_inverse: bool = False, color_threshold: int = 128,
                 debug: bool = False):
        """

        :param marker_matrix_size: Marker size in bits with black border
        :param scale: Scale value for image warping with homography
                      A value of 6 means that a 6x6 matrix is sampled
                     for each marker bit.
        :param marker_ids: A list of detectable marker IDs
        """
        self._marker_matrix_size = marker_matrix_size
        self._scale = scale
        self._color_inverse = color_inverse
        self._color_threshold = color_threshold
        self._debug = debug

        # Calculate the desired marker image size after application of the homography matrix
        self._marker_img_size = (
            self._marker_matrix_size[0] * self._scale, self._marker_matrix_size[1] * self._scale)
        # Calculate the 2D marker coordinates for the calculation of the homography matrix
        self._marker_scan_corners_2d = np.array([(-0.5, -0.5),
                                                 (self._marker_img_size[0] -
                                                  0.5, -0.5),
                                                 (self._marker_img_size[0] - 0.5,
                                                  self._marker_img_size[1] - 0.5),
                                                 (-0.5, self._marker_img_size[1] - 0.5)],
                                                np.float32).reshape((-1, 1, 2))

        # Create the marker alphabet
        self._marker_ids = marker_ids
        self._marker_codes = []
        self.set_marker_ids(marker_ids)

    def set_marker_ids(self, marker_ids):
        """
        Set the list of detectable marker IDs

        :param marker_ids: List of the marker IDs that can be detected
        """
        # Update the marker alphabet
        self._marker_ids = [id for id in marker_ids]
        self._marker_codes = [HammingCodes.hamming_code_n15(
            code) for code in self._marker_ids]

    def identify_marker(self, gray_image, marker_points) -> Tuple[bool, int, np.ndarray]:
        """
        Identify a marker based on the inner pixel values

        The homography matrix is calcualted for each maker to generate
        an artificial top view of the marker (cv2.findHomography and
        cv2.warpPerspective). After that the binarized bit code is read
        into a marker matrix. This matrix is finally converted into the
        real marker code. During this process the marker orientation is
        also determined by inspecting the orientation corner bits.

        :param gray_image: The original gray scale image
        :param marker_points: The marker edge points in the image
        :return: A tuple of:
                 - A boolean indicating whether the marker could
                   be successfully identified
                 - The ID of the marker. None if the identification failed
                 - The corrected marker points (rotated to fit the marker
                   orientation). The marker points are only modified if
                   the identification was successful.
                 - The rectified marker image
        """

        # Calculate the homography matrix
        homography, _ = cv2.findHomography(srcPoints=marker_points,
                                           dstPoints=self._marker_scan_corners_2d)

        # Create an artificial top view with the calculated homography
        rectangular_img = cv2.warpPerspective(src=gray_image,
                                              M=homography,
                                              dsize=self._marker_img_size,
                                              flags=cv2.INTER_LINEAR)

        # Read and validate the marker code
        marker_id = None
        valid_marker = False
        code_valid, code_mat = self._read_bit_code(rectangular_img)
        if code_valid:
            valid_code, code, n_rotations = self._matrix_to_code(code_mat)
            if valid_code:
                success, marker_id = self._get_marker_id(code)
                if success:
                    self.logger.debug("Marker is rotated %d degree",
                                      n_rotations*90)
                    marker_points = np.roll(
                        marker_points, -n_rotations, axis=0)
                    valid_marker = True

        if self._debug:
            cv2.imshow("Marker", rectangular_img)
            cv2.waitKey()

        return valid_marker, marker_id, marker_points

    def _read_bit_code(self, rect_image) -> Tuple[bool, np.ndarray]:
        """
        // Das rectifizierte Markerbild (Markerdraufsicht) wird ausgelesen und binarisiert.
        // Als Rueckgabe erhaelt man die binarisierte Darstellung der inneren Markerbits als
        // Matrix. Fuer die Binarisierung wird der Mittelwert eines SCALE*SCALE großen Feldes
        // gebildet und anhand eines festen Schwellwertes (Wert = 127) binarisiert.
        // Fuer die Bits am Rand des Markers wird geprüft, ob diese den Wert 0 haben.
        // Ist dies nicht der Fall, wird false zurueckgegeben, sonst true.
        :param rect_image:
        :return:
        """
        result = np.zeros(
            (self._marker_matrix_size[0] - 2, self._marker_matrix_size[1] - 2), np.uint8)
        for i in range(self._marker_matrix_size[1]):
            for j in range(self._marker_matrix_size[0]):

                # Compute the bit value at (i, j) by averaging and thresholding
                # a SCALE * SCALE rectangular marker bit field
                mean_val = 0
                for k in range(self._scale):
                    for _ in range(self._scale):
                        mean_val += rect_image[self._scale *
                                               i + k, self._scale * j + 1]
                mean_val /= self._scale * self._scale
                bit = 0 if mean_val < self._color_threshold else 1
                self.logger.debug("(%d, %d): mean=%f, binary=%s",
                                  i, j, mean_val, bit)
                if self._color_inverse:
                    bit = 1 if bit == 0 else 0

                # Perform marker characteristic checks:
                # Currently only the black border is checked
                if (i == 0 and bit != 0) or \
                   (i == self._marker_matrix_size[1] - 1 and bit != 0) or \
                   (j == 0 and bit != 0) or \
                   (j == self._marker_matrix_size[0] - 1 and bit != 0):
                    self.logger.debug("Marker border check failed")
                    return False, result

                if 0 < i < self._marker_matrix_size[1] - 1 and \
                   0 < j < self._marker_matrix_size[0] - 1:
                    result[i - 1, j - 1] = bit

        self.logger.debug("Marker bit code successfully read: %s", result)

        return True, result

    @classmethod
    def _matrix_to_code(cls, matrix_mat) -> Tuple[bool, int, int]:
        """
        // Die uebergebene Matrix mat enthaelt die inneren Bits des Markers in einer
        // beliebigen n*90 Grad Rotation n={0,1,2,3}.
        // Die Bits in den Ecken sind weiß mit Ausnahme des Bits recht unten in der Ecke
        // In dieser Orientierung wird der Marker-Code ausgelesen und zurueckgegeben,
        // sonst Rueckgabe des Wertes -1. Zusaetzlich wird in nRotations die Anzahl der
        // 90 Grad Rotation zurueckgegeben: 0 Grad = 0, 90 Grad = 1, 180 Grad = 2, ...
        :param matrix_mat:
        :return:
        """

        # 0 degree rotation
        if matrix_mat[0, 0] == 1 and \
                matrix_mat[0, 3] == 1 and \
                matrix_mat[3, 0] == 1 and \
                matrix_mat[3, 3] == 0:
            success = True
            n_rotations = 0
            code = matrix_mat[0, 1] << 11 | \
                matrix_mat[0, 2] << 10 | \
                matrix_mat[1, 0] << 9 | \
                matrix_mat[1, 1] << 8 | \
                matrix_mat[1, 2] << 7 | \
                matrix_mat[1, 3] << 6 | \
                matrix_mat[2, 0] << 5 | \
                matrix_mat[2, 1] << 4 | \
                matrix_mat[2, 2] << 3 | \
                matrix_mat[2, 3] << 2 | \
                matrix_mat[3, 1] << 1 | \
                matrix_mat[3, 2]

        # 90 degree rotation (clockwise!)
        elif matrix_mat[0, 0] == 1 and \
                matrix_mat[0, 3] == 1 and \
                matrix_mat[3, 0] == 0 and \
                matrix_mat[3, 3] == 1:
            success = True
            n_rotations = 1
            code = matrix_mat[1, 3] << 11 | \
                matrix_mat[2, 3] << 10 | \
                matrix_mat[0, 2] << 9 | \
                matrix_mat[1, 2] << 8 | \
                matrix_mat[2, 2] << 7 | \
                matrix_mat[3, 2] << 6 | \
                matrix_mat[0, 1] << 5 | \
                matrix_mat[1, 1] << 4 | \
                matrix_mat[2, 1] << 3 | \
                matrix_mat[3, 1] << 2 | \
                matrix_mat[1, 0] << 1 | \
                matrix_mat[2, 0]

        # 180 degree rotation
        elif matrix_mat[0, 0] == 0 and \
                matrix_mat[0, 3] == 1 and \
                matrix_mat[3, 0] == 1 and \
                matrix_mat[3, 3] == 1:
            success = True
            n_rotations = 2
            code = matrix_mat[3, 2] << 11 | \
                matrix_mat[3, 1] << 10 | \
                matrix_mat[2, 3] << 9 | \
                matrix_mat[2, 2] << 8 | \
                matrix_mat[2, 1] << 7 | \
                matrix_mat[2, 0] << 6 | \
                matrix_mat[1, 3] << 5 | \
                matrix_mat[1, 2] << 4 | \
                matrix_mat[1, 1] << 3 | \
                matrix_mat[1, 0] << 2 | \
                matrix_mat[0, 2] << 1 | \
                matrix_mat[0, 1]

        # 270 degree rotation (clockwise))
        elif matrix_mat[0, 0] == 1 and \
                matrix_mat[0, 3] == 0 and \
                matrix_mat[3, 0] == 1 and \
                matrix_mat[3, 3] == 1:
            success = True
            n_rotations = 3
            code = matrix_mat[2, 0] << 11 | \
                matrix_mat[1, 0] << 10 | \
                matrix_mat[3, 1] << 9 | \
                matrix_mat[2, 1] << 8 | \
                matrix_mat[1, 1] << 7 | \
                matrix_mat[0, 1] << 6 | \
                matrix_mat[3, 2] << 5 | \
                matrix_mat[2, 2] << 4 | \
                matrix_mat[1, 2] << 3 | \
                matrix_mat[0, 2] << 2 | \
                matrix_mat[2, 3] << 1 | \
                matrix_mat[1, 3]
        else:
            cls.logger.debug("Marker corner bit check failed")
            success = False
            code = -1
            n_rotations = -1

        return success, int(code), n_rotations

    def _get_marker_id(self, code: int) -> Tuple[bool, int]:
        """
        // Der uebergebene und im Bild detektierte Code wird gegen alle
        // im Alphabet/Lexikon gespeicherten Marker-IDs verglichen. Wenn kein
        // Fehler im Code vorhanden ist, dann erfolgt eine Rueckgabe der ID,
        // sonst wird bei einem Fehler von einem Bit versucht den Code zu
        // korrigieren und die rekonstruierte ID zuruekgegeben. Ansonsten
        // wird -1 zurueckgegeben.
        :param code:
        :return:
        """
        # Calculate Hamming distance
        min_error = sys.maxsize
        min_index = -1
        for i, marker_code in enumerate(self._marker_codes):
            h_dist = HammingCodes.hamming_distance(marker_code, code, 15)
            if h_dist < min_error:
                min_error = h_dist
                min_index = i

        # Error correction with Hamming codes
        if min_error == 1:
            error_pos = HammingCodes.error_in_bit_pos(int(code))
            self.logger.warning("Correcting error in marker code at bit pos %d",
                                error_pos)
            code ^= (1 << (error_pos - 1))
            if code != self._marker_codes[min_index]:
                # Error correction failed (wrong / unknown marker code)
                min_index = -1

        marker_id = -1
        success = False
        if min_error == 0:
            marker_id = self._marker_ids[min_index]
            success = True
        elif min_error == 1 and min_index != -1:
            marker_id = self._marker_ids[min_index]
            success = True

        return success, marker_id
