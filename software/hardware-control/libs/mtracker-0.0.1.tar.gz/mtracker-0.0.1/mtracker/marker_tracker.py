import sys
import logging
from random import randint
from typing import Iterable

import cv2
import numpy as np

from .marker import Marker
from .marker_identifier import MarkerIdentifier


class MarkerTracker:
    """
    Scale value for image warping with homography
    A value of 6 means that a 6x6 matrix is sampled
    for each marker bit.
    """
    SCALE = 6

    logger = logging.getLogger(__module__)

    def __init__(self, marker_size=(100, 100),
                 marker_identifier: MarkerIdentifier = None,
                 camera_matrix: np.ndarray = np.eye(3),
                 dist_coefficients: np.ndarray = np.zeros(5),
                 contour_epsilon=5.0, debug=False):
        """
        Initialize a marker tracker

        :param marker_size: Marker size as tuple (width, height) in mm,
                            defaults to (100, 100)
        :type marker_size: tuple, optional
        :param marker_identifier: [description], defaults to None
        :type marker_identifier: MarkerIdentifier, optional
        :param debug: [description], defaults to False
        :type debug: bool, optional
        """

        # Whether to show intermediate results for debugging
        self.debug = debug

        # Min. contour size in pixel
        self._contour_epsilon = contour_epsilon
        self._min_contour_pixels = 100
        self._marker_identifier = marker_identifier

        self._marker_size = marker_size
        self._marker_corners_3d = None

        # Initialize the camera calibration matrix and distortion matrix
        self._cam_matrix = camera_matrix.copy()
        self._dist_coeff = dist_coefficients.copy()

    def detect_markers(self, image: np.ndarray,
                       use_corner_refinement: bool = True) -> Iterable[Marker]:
        """
        Detects all markers in the image and returns a list of
        transformation matrices for the detected markers.
        :param image: The image.
        :return: A list of marker transformation matrices.
        """

        if len(image.shape) != 3 or image.shape[2] != 3:
            raise ValueError(f"Image file format with {len(image.size)} "
                             "image channels is not supported")
        if image.dtype != np.uint8:
            raise ValueError(f"Invalid image data type {image.dtype}")

        # Convert into gray scale
        grayscale_img = cv2.cvtColor(src=image,
                                     code=cv2.COLOR_BGR2GRAY)

        # Denoise the image with a median blur
        blurred_img = cv2.medianBlur(grayscale_img, ksize=5)

        # Create a binary image (edges)
        threshold_img = cv2.adaptiveThreshold(src=blurred_img,
                                              maxValue=255,
                                              adaptiveMethod=cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                              thresholdType=cv2.THRESH_BINARY_INV,
                                              blockSize=5,
                                              C=7)

        if self.debug:
            cv2.imshow("Thresholded image", threshold_img)
            cv2.waitKey()

        # Find contours in the binary image
        contours, _ = cv2.findContours(image=threshold_img,
                                       mode=cv2.RETR_LIST,
                                       method=cv2.CHAIN_APPROX_NONE)

        # Remove small contours
        filtered_contours = [
            c for c in contours if c.shape[0] > self._min_contour_pixels]
        self.logger.debug("%s contours founds", len(filtered_contours))

        if self.debug:
            # Display the filtered contours
            contour_img = image.copy()
            for contour in filtered_contours:
                cv2.drawContours(image=contour_img,
                                 contours=[contour],
                                 contourIdx=-1,
                                 color=(randint(0, 255), randint(
                                     0, 255), randint(0, 255)),
                                 thickness=2)
            cv2.imshow("Contours", contour_img)
            cv2.waitKey()

        # Find contours that are likely to be markers
        marker_candidates = self._find_marker_candidates(
            filtered_contours, image)
        self.logger.debug("%d marker candidates identified",
                          len(marker_candidates))

        # Verify and identify the markers.
        markers = self.recognize_markers(grayscale_img,
                                         marker_candidates,
                                         use_corner_refinement)

        self.logger.debug("%d markers recognized", len(markers))

        # Calculate the marker poses.
        markers = self.estimate_marker_poses(markers)

        if self.debug:
            marker_img = image.copy()
            self.draw_markers(marker_img, markers)
            cv2.imshow("Detected markers", marker_img)

        return markers

    def _find_marker_candidates(self, contours, image):
        """
        TODO Translate comments
        // Uebergeben wird ein Vektor von Konturen. Jede Kontur wird in der Methode
        // abgearbeitet. Jeweils wird mit cv::approxPolyDP ein Polygon approximiert
        // und geprueft, ob dieses genau 4 Eckpunkte enthaelt und die Form konvex ist
        // (siehe cv::isContourConvex). Dann wird die kleinste Seitenlaenge des Polygons
        // ermittelt und geprueft, ob diese ein Viertel der minimalen Konturlaenge in Pixeln
        // ueberschreitet. Dann werden die Punkte so sortiert, dass sie in mathematisch-
        // positiver Umlaufrichtung gespeichert sind. Desweiteren werden Konturen aussortiert,
        // die nahezu gleich verlaufen, d.h. Schwerpunkt liegt nahe beieinander und die
        // eingeschlossene Flaeche ist aehnlich gross (Marker in Marker soll nicht moeglich sein).
        :param contours:
        :return:
        """
        possible_markers = []

        # For each contour, analyze if it is a parallelogram likely to be a marker
        for contour in contours:
            """
            if self.debug:
                # Display the filtered contours
                contour_img = image.copy()
                cv2.drawContours(image=contour_img,
                                 contours=[contour],
                                 contourIdx=-1,
                                 color=(randint(0, 255), randint(
                                        0, 255), randint(0, 255)),
                                 thickness=1)
                cv2.imshow("Current contour", contour_img)
                cv2.waitKey()
            """

            # Approximate the contour with a polygon
            polygon = cv2.approxPolyDP(curve=contour,
                                       epsilon=self._contour_epsilon,
                                       closed=True)
            # We only need contours with 4 vertices, that is a completely visible marker!
            if polygon.shape[0] != 4:
                self.logger.debug(
                    "Dropping contour: Contour has not 4 vertices")
                continue

            # The contour must also be convex
            if not cv2.isContourConvex(polygon):
                self.logger.debug("Dropping contour: Contour is not convex")
                continue

            # Calculate the shortest polygon edge
            min_dist = sys.float_info.max
            for i in range(polygon.shape[0]):
                vec = (polygon[i, 0, 0] - polygon[(i+1) % 4, 0, 0],
                       polygon[i, 0, 1] - polygon[(i+1) % 4, 0, 1])
                squared_dist = vec[0] * vec[0] + vec[1] * vec[1]
                min_dist = min(min_dist, squared_dist)

            # The shortest edge must be at longer than a quarter of the minimal
            # contour length in pixel
            if min_dist > self._min_contour_pixels * 0.25:
                marker = Marker(size=self._marker_size, contour=contour)
                marker.image_points = polygon.reshape(-1, 2).astype(np.float32)
                possible_markers.append(marker)
            else:
                self.logger.debug("Dropping contour: Min. edge is too short")

        # Sort the polygon vertices to be in mathematical positive order.
        # This step is necessary for the correct calculation of the rotation
        # matrix in the following steps.
        for marker in possible_markers:
            """
            TODO Translate comment
            // Es wird zwischen dem ersten und dem zweiten Punkt ein Vektor aufgespannt.
            // Spannt man dann einen Vektor zwischen dem ersten und dem dritten Punkt auf,
            // und berechnet das Vektorprodukt, dann zeigt dieser in die Blickrichtung der
            // Kamera, wenn der dritte Punkt im Uhrzeigersinn (mathematisch positiv) liegt.
            // Der dritte Punkt liegt in mathematisch negativer Umlaufrichtung, wenn das
            // Kreuzprodukt aus der Bildflaeche zum Betrachter zeigt.
            """
            v1 = marker.image_points[1, :] - marker.image_points[0, :]
            v2 = marker.image_points[2, :] - marker.image_points[0, :]
            # Calculate the squared norm of the vector product along th z axis
            o = (v1[0] * v2[1]) - (v1[1] * v2[0])

            # If the value is negative, the vertex order is not correct
            # and we have to swap vertex 2 and 4.
            tmp = marker.image_points[1, :].copy()
            marker.image_points[1, :] = marker.image_points[3, :].copy()
            marker.image_points[3, :] = tmp

        # Remove contours which are almost the same, that distance between
        # the center of gravity is very small and the polygon area is very
        # similar.
        removal_mask = np.zeros((len(possible_markers)))

        for i in range(len(possible_markers)):
            m1 = possible_markers[i]

            for j in range(i + 1, len(possible_markers)):
                m2 = possible_markers[j]

                # Calculate the center of gravity
                c1 = [0.0, 0.0]
                c2 = [0.0, 0.0]
                for k in range(4):
                    c1[0] += m1.image_points[k, 0]
                    c1[1] += m1.image_points[k, 1]
                    c2[0] += m2.image_points[k, 0]
                    c2[1] += m2.image_points[k, 1]
                c1[0] = c1[0] / 4
                c1[1] = c1[1] / 4
                c2[0] = c2[0] / 4
                c2[1] = c2[1] / 4

                dist = (c1[0] - c2[0], c1[1] - c2[1])

                # Calculate the squared distance between the center of gravity
                # of both shapes
                dist_squared = (dist[0] * dist[0] + dist[1] * dist[1])

                if dist_squared < 50:
                    # Calculate and compare the contour areas
                    area_1 = cv2.contourArea(m1.image_points)
                    area_2 = cv2.contourArea(m2.image_points)

                    if area_1 < area_2:
                        if (area_2 - area_1) / area_1 < 0.1:
                            # Delete marker 1
                            removal_mask[i] = 1
                    else:
                        if (area_1 - area_2) / area_2 < 0.1:
                            # Delete marker 2
                            removal_mask[j] = 1

        markers = []
        for i in range(len(possible_markers)):
            if removal_mask[i] == 0:
                markers.append(possible_markers[i])

        return markers

    def recognize_markers(self, gray_image: np.ndarray,
                          possible_markers: Iterable[Marker],
                          use_corner_refinement: bool = True) -> Iterable[Marker]:
        """
        For each detected marker the marker corners are refined with
        subpixel accuracy (cv2.cornerSubPix). Each marker is then
        identified with the given marker identifier.

        :param gray_image: The gray scale image in which the markers
                           have been detected
        :param possible_markers: A list of marker candidates
        :return: A list with all markers that could be successfully identified
        """

        good_markers = []

        for marker in possible_markers:
            # Find the marker corners with sub-pixel accuracy
            tmp_points = marker.image_points.reshape(4, 1, 2)
            tmp_points = tmp_points.astype(np.float32)

            if use_corner_refinement:
                subpix_corners = cv2.cornerSubPix(image=gray_image,
                                                  corners=tmp_points,
                                                  winSize=(3, 3),
                                                  zeroZone=(-1, -1),
                                                  criteria=(cv2.TERM_CRITERIA_EPS
                                                            + cv2.TERM_CRITERIA_MAX_ITER,
                                                            30, 0.001))
                marker.image_points = subpix_corners.reshape(-1, 2)
            else:
                rect = cv2.minAreaRect(tmp_points)
                box = cv2.boxPoints(rect)
                box = np.int0(box)
                marker.image_points = box.reshape(4, 2).astype(np.float32)

            # Identify the marker
            success, marker_id, marker_points = self._marker_identifier.identify_marker(
                gray_image, marker.image_points)
            if success:
                marker.id = marker_id
                marker.image_points = marker_points
                good_markers.append(marker)

        return good_markers

    def estimate_marker_poses(self, markers):
        """
        Calculate the marker pose for each detected marker using the
        solvePnP method implemented in OpenCV.

        The calculated transformations are stored in the passed marker objects
        :param markers: A list with valid markers
        :return: The same list with markers passed to the method. The calculated
                 transformations are set in the marker objects
        """

        for marker in markers:
            # Calculate the marker pose with solvePnP
            success, r_vec, t_vec = cv2.solvePnP(objectPoints=marker.local_points.reshape(-1, 1, 3),
                                                 imagePoints=marker.image_points.reshape(
                                                     -1, 1, 2),
                                                 cameraMatrix=self._cam_matrix,
                                                 distCoeffs=self._dist_coeff,
                                                 flags=cv2.SOLVEPNP_ITERATIVE)
            print(success, r_vec, t_vec)
            if not success:
                # Failed to calculate the marker pose
                # TODO Set failure flag in the marker
                return

            # Calculate the rotation matrix from
            # the Rodrigues angles
            print("r_vec:", r_vec)
            r_mat, _ = cv2.Rodrigues(src=r_vec)

            # Store the complete marker transformation
            tmat = np.eye(4)
            tmat[0:3, 0:3] = r_mat
            tmat[0:3, 3] = t_vec.reshape(-1)
            marker.transformation = tmat

        return markers

    @staticmethod
    def draw_markers(image, markers, draw_edges=True, draw_vertices=True):
        for marker in markers:
            # Prepare the contour vertices
            v = [marker.image_points.copy().reshape(-1, 1, 2).astype(np.int32)]

            # Draw the edges
            if draw_edges:
                v = [marker.image_points.copy().reshape(-1, 1, 2).astype(np.int32)]
                cv2.drawContours(image=image,
                                 contours=v,
                                 contourIdx=-1,
                                 color=(randint(0, 254), randint(
                                     0, 254), randint(0, 254)),
                                 thickness=2)
            # Draw the vertices
            if draw_vertices:
                for i in range(4):
                    cv2.circle(img=image,
                               center=(int(marker.image_points[i, 0]), int(
                                   marker.image_points[i, 1])),
                               radius=3,
                               color=(0, 0, 255))

            # Show the marker ID
            moments = cv2.moments(v[0])
            cx = int(moments['m10'] / moments['m00'])
            cy = int(moments['m01'] / moments['m00'])

            cv2.putText(img=image,
                        text=str(marker.id),
                        org=(int(cx), int(cy)),
                        fontFace=cv2.FONT_HERSHEY_PLAIN,
                        fontScale=6.0,
                        color=(0, 0, 255))

        return image
