import cv2
import numpy as np

from .marker_identifier import MarkerIdentifier


class SimpleMarkerIdentifier(MarkerIdentifier):

    def __init__(self, marker_size=(20, 20), border_width=1, debug=True):
        """

        :param marker_size: The marker size as tuple of (width, height) in mm
        :param border_width: The size of the white marker border in mm
        """
        self._marker_size = marker_size
        self._border_width = border_width
        self._scale = 10
        self._debug = debug

        self._marker_img_size = (
            self._marker_size[0] * self._scale, self._marker_size[1] * self._scale)
        # Calculate the 2D marker coordinates for the calculation of the homography matrix
        img_border = self._border_width * self._scale
        self._marker_corners_2d = np.array([(-img_border, -img_border),
                                            (self._marker_img_size[0] +
                                             img_border, -img_border),
                                            (self._marker_img_size[0] + img_border,
                                             self._marker_img_size[1] + img_border),
                                            (-img_border, self._marker_img_size[1] + img_border)], np.float32).reshape((-1, 1, 2))

    def identify_marker(self, gray_image, image, marker_points):

        # Calculate the homography matrix
        h, _ = cv2.findHomography(srcPoints=marker_points,
                                  dstPoints=self._marker_corners_2d)

        # Create an artificial top view with the calculated homography
        dsize = [int(self._marker_img_size[0]), int(self._marker_img_size[1])]
        rectangular_img = cv2.warpPerspective(src=gray_image,
                                              M=h,
                                              dsize=dsize,
                                              flags=cv2.INTER_LINEAR)
        if self._debug:
            cv2.imshow('Marker', rectangular_img)
            cv2.waitKey()

        # Find the 'white' lower right corner
        avgs = np.zeros((2, 2))
        steps = (int(self._marker_img_size[0] * 0.5),
                 int(self._marker_img_size[1] * 0.5))
        for i in range(2):
            for j in range(2):
                avgs[i, j] = rectangular_img[i * steps[0]: (i + 1) * steps[0],
                                             j * steps[1]: (j + 1) * steps[1]].sum()
        max_field = np.argmax(avgs)

        # Rotate the marker into it's original orientation
        n_rotations = 0
        if max_field == 0:
            n_rotations = 2
        elif max_field == 1:
            n_rotations = 1
        elif max_field == 2:
            n_rotations = 3
        marker_points = np.roll(marker_points, n_rotations, axis=0)

        return True, 1, marker_points
