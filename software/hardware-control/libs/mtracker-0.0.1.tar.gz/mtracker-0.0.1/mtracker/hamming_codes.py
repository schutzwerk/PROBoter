from sys import getsizeof


class HammingCodes:

    @staticmethod
    def active_bits(data: int, num_bits: int = None) -> int:
        if num_bits is not None and num_bits <= 0:
            raise ValueError("num_bits must be greater than zero.")

        if num_bits is None:
            num_bits = getsizeof(data) * 8

        res = 0
        for i in range(num_bits-1, -1, -1):
            if data & (1 << i):
                res += 1
        return res

    @staticmethod
    def hamming_distance(code: int, measured_code: int, num_bits: int = None) -> int:
        if num_bits is None:
            num_bits = getsizeof(code) * 8

        val = code ^ measured_code
        return HammingCodes.active_bits(val, num_bits)

    @staticmethod
    def hamming_code_n15(data: int) -> int:
        if data < 0 or data > 2047:
            raise ValueError("Data must be in the range of 0 to 2047")

        code = data << 4

        p1_tmp = data & 1371
        p1 = HammingCodes.active_bits(p1_tmp, 11) % 2

        p2_tmp = data & 1645
        p2 = HammingCodes.active_bits(p2_tmp, 11) % 2

        p3_tmp = data & 1934
        p3 = HammingCodes.active_bits(p3_tmp, 11) % 2

        p4_tmp = data & 2032
        p4 = HammingCodes.active_bits(p4_tmp, 11) % 2

        parity_data = p4 << 3 | p3 << 2 | p2 << 1 | p1

        code = code | parity_data

        return code

    @staticmethod
    def error_in_bit_pos(code: int) -> int:
        p4_tmp = code & 32520
        p4 = HammingCodes.active_bits(p4_tmp, 15) % 2

        p3_tmp = code & 30948
        p3 = HammingCodes.active_bits(p3_tmp, 15) % 2

        p2_tmp = code & 26322
        p2 = HammingCodes.active_bits(p2_tmp, 15) % 2

        p1_tmp = code & 21937
        p1 = HammingCodes.active_bits(p1_tmp, 15) % 2

        error_pos = p4 << 3 | p3 << 2 | p2 << 1 | p1

        # Take in concern swapped bit positions!
        if error_pos == 3:
            error_pos = 5
        elif error_pos == 4:
            error_pos = 3
        elif error_pos == 5 or error_pos == 6 or error_pos == 7:
            error_pos += 1
        elif error_pos == 8:
            error_pos = 4

        return error_pos

    @staticmethod
    def print_binary(data: int, num_bits: int) -> None:
        if num_bits < 1:
            num_bits = getsizeof(data) * 8
        for i in range(num_bits-1, -1, -1):
            print("1" if data & (1 << i) else "0",
                  sep="", end="\n" if i == 0 else "", flush=True)
