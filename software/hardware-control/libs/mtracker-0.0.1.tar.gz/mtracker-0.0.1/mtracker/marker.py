import logging
from typing import Tuple

import numpy as np

from .hamming_codes import HammingCodes


class Marker:
    """
    Trackable 2D marker
    """

    logger = logging.getLogger(__module__)

    MARKER_SIZE = 6

    def __init__(self, marker_id=-1, size=(20, 20), image_points=np.empty((4, 2)),
                 transformation=np.eye(4), contour: np.ndarray = np.empty((0, 2))):
        self.id = marker_id
        self._size = size
        self._contour = contour
        self._image_points = image_points
        self._transformation = transformation

    @property
    def size(self) -> Tuple[float, float]:
        """
        Return the marker size as tuple of (width, height)
        """
        return self._size

    @property
    def contour(self) -> np.ndarray:
        """
        Return the marker's raw contour points as (nx2) array
        """
        return self._contour

    @ property
    def image_points(self) -> np.ndarray:
        """
        Return the marker image points as (4x2) matrix
        """
        return self._image_points

    @ image_points.setter
    def image_points(self, new_points: np.ndarray) -> None:
        """
        Set the marker image points as (4x2) matrix
        """
        if not isinstance(new_points, np.ndarray):
            raise ValueError("Maker points must be a numpy array")
        if not new_points.shape == (4, 2):
            raise ValueError("Marker points must be a (4x2) matrix")
        self._image_points = new_points

    @ property
    def transformation(self) -> np.ndarray:
        """
        Return the (4x4) matrix that defines the transformation of
        the marker in the camera system
        """
        return self._transformation

    @ transformation.setter
    def transformation(self, new_transformation: np.ndarray) -> None:
        """
        Set the (4x4) matrix that defines the transformation of
        the marker in the camera system
        """
        if not isinstance(new_transformation, np.ndarray):
            raise ValueError("Marker transformation must be a numpy array")
        if not new_transformation.shape == (4, 4):
            raise ValueError("Marker transformation must be a (4x4) matrix")
        self._transformation = new_transformation

    @ property
    def translation(self) -> np.ndarray:
        """
        Return the marker translation in the camera system as 3D vector
        """
        return self.transformation[0:3, 3]

    @ property
    def rotation(self) -> np.ndarray:
        """
        Return the marker rotation in the camera system as (3x3) rotation matrix
        """
        return self.transformation[0:3, 0:3]

    @ property
    def local_points(self) -> np.ndarray:
        """
        Return the marker corner points in the marker's local coordinate system
        """
        return np.array(((-0.5 * self.size[0], +0.5 * self.size[1], 0.0),
                         (+0.5 * self.size[0], +
                          0.5 * self.size[1], 0.0),
                         (+0.5 * self.size[0], -
                          0.5 * self.size[1], 0.0),
                         (-0.5 * self.size[0], -0.5 * self.size[1], 0.0)),
                        dtype=np.float32)

    @ property
    def global_points(self) -> np.ndarray:
        """
        The marker points in the camera system
        """
        marker_points = np.ones((4, 4))
        marker_points[:, :3] = self.local_points
        return np.matmul(self.transformation, marker_points.T).T[:, 0:3]

    def __str__(self):
        return (f"[Marker: id={self.id}, "
                f"size={self.size},"
                f"image_points={self.image_points.tolist()}, "
                f"transformation={self.transformation.tolist()}]")

    def __repr__(self) -> str:
        return self.__str__()

    @ classmethod
    def generate_marker_image(cls, marker_id: int, size: int = 900,
                              inverted: bool = False) -> np.ndarray:
        """
        Generates an marker image with the given marker ID

        :param marker_id: The marker ID
        :param size: The size of the output image in pixel
        :return: A two channel gray scale image as numpy array of the
                 given size representing the marker
        """
        if not 0 <= marker_id <= 255:
            raise Exception("Marker ID must be in the range of [1...256]")

        if size % cls.MARKER_SIZE != 0:
            new_size = (size / cls.MARKER_SIZE) * cls.MARKER_SIZE
            cls.logger.warning("Adjusting the size to the next multiple of %d: %d",
                               cls.MARKER_SIZE, new_size)
            size = new_size

        marker_encoded = HammingCodes.hamming_code_n15(marker_id)

        # Initialize the marker grid
        marker_img = np.zeros((int(size), int(size)), np.uint8)

        high_val = 255
        low_val = 0
        if inverted:
            high_val = 0
            low_val = 255

        marker_img[:, :] = low_val

        bit_size = int(size / cls.MARKER_SIZE)

        # Set the orientation bits
        for bit_pos in [(1, 1), (1, 4), (4, 1)]:
            marker_img = cls._set_marker_patch(
                marker_img, bit_pos, bit_size, high_val)

        # Set Hamming code bits
        for i in range(12):
            bit_value = high_val if marker_encoded & (1 << i) else low_val
            marker_img = cls._set_marker_bit(
                marker_img, i, bit_size, bit_value)

        return marker_img

    @ staticmethod
    def _set_marker_patch(marker_image: np.ndarray, patch_pos: int,
                          patch_size: int, value: int) -> np.ndarray:
        """
        Sets all bits in an marker image patch to a certain value

        :param marker_image: The marker image
        :param patch_pos: The patch position as a tuple of (y, x) value
        :param patch_size: The patch size in pixel
        :param value: The value to set the patch pixel to
        :return: The modified patch image
        """
        marker_image[patch_pos[0] * patch_size: (patch_pos[0] + 1) * patch_size,
                     patch_pos[1] * patch_size: (patch_pos[1] + 1) * patch_size] = value
        return marker_image

    @ classmethod
    def _set_marker_bit(cls, marker_image: np.ndarray, bit_pos: int,
                        patch_size: int, value: int) -> np.ndarray:
        """
        Writes a single bit to a marker image according to the following
        bit matrix

        -------------------------
        |   x |  11 |  10 |   x |
        |-----------------------|
        |   9 |   8 |   7 |   x |
        |-----------------------|
        |   5 |   4 |   3 |   x |
        |-----------------------|
        |   x |   1 |   0 |   x |
        -------------------------

        :param marker_image: The marker image
        :param bit_pos: The bit position
        :param patch_size: The size of a single bit / patch in the marker image
        :param value: The value to set the patch pixel to
        :return: The modified marker image
        """
        patch_pos = cls.bit_pos_to_marker_pos(bit_pos)
        marker_image = cls._set_marker_patch(
            marker_image, patch_pos, patch_size, value)

        return marker_image

    @ classmethod
    def bit_pos_to_marker_pos(cls, bit_pos: int) -> Tuple[int, int]:
        """
        Calculate the marker coordinates for a given bit position

        -------------------------
        |   x |  11 |  10 |   x |
        |-----------------------|
        |   9 |   8 |   7 |   x |
        |-----------------------|
        |   5 |   4 |   3 |   x |
        |-----------------------|
        |   x |   1 |   0 |   x |
        -------------------------

        :param bit_pos: The bit position
        :return: The marker coordinate of the bit as tuple of (x, y)
                 in the range of [1, ..., MARKER_SIZE]
        """
        if bit_pos not in range(12):
            raise Exception("Bit position must be in the range of [0...11]")

        bit_pos_map = {
            0: (4, 3),
            1: (4, 2),
            2: (3, 4),
            3: (3, 3),
            4: (3, 2),
            5: (3, 1),
            6: (2, 4),
            7: (2, 3),
            8: (2, 2),
            9: (2, 1),
            10: (1, 3),
            11: (1, 2)
        }

        return bit_pos_map[bit_pos]
