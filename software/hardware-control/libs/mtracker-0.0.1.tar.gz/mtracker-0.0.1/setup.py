from os.path import abspath, dirname, join
from setuptools import setup, find_packages


projectDir = abspath(dirname(__file__))

with open(join(projectDir, 'README.md')) as f:
    long_description = f.read()

setup(
    name='mtracker',
    version='0.0.1',
    description='mtracker - Simple marker tracking framework',
    long_description=long_description,
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Operating System :: OS Independent',
        'Environment :: Console'
    ],
    keywords='computer vision, marker tracking',
    url='https://github.com/schutzwerk/mtracker',
    author='SCHUTZWERK GmbH',
    author_email='info@schutzwerk.com',
    license='GNU General Public License v3 (GPLv3)',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'numpy',
        'opencv-python',
        'svgwrite'
    ],
    entry_points={
        'console_scripts': [
            'marker-generate = mtracker:generate_marker_images',
            'marker-grid-generate = mtracker:generate_marker_grid',
        ],
    },
    python_requires='>=3.6'
)
