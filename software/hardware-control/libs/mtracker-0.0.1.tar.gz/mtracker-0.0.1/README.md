# mtracker

A simple optical marker tracker implemented in Python + OpenCV. The tracker is based on the content of the lecture **Computer Vision** held by Professor Dr. Klaus Ulhaas at the [University of Applied Sciences Kempten](https://www.hs-kempten.de).


## Install
`mtracker` is packed as Python package that can be easily installed with [pip](https://pypi.org/project/pip/). You can install `mtracker` globally in your main Python interpreter or a separate virtual environment with the following command:

```
pip install git+ssh://git@git.ulm.schutzwerk.net/tools/proboter/mtracker.git@master#egg=mtracker
```
