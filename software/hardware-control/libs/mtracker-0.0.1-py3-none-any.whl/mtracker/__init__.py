import os
import cv2
import argparse

from .hamming_codes import *
from .marker_grid import *
from .marker import *

from .marker_tracker import *
from .hamming_marker_identifier import *
from .simple_marker_identifier import *


def generate_marker_images():
    parser = argparse.ArgumentParser('Generate Marker Images')
    parser.add_argument('out_dir', metavar='OUTPUT_DIR', type=str)
    args = parser.parse_args()

    min_marker_id = 1
    max_marker_id = 256
    print(
        f'[*] Generating marker images in \'{os.path.abspath(args.out_dir)}\'')
    for marker_id in range(min_marker_id, max_marker_id):
        marker_image = Marker.generate_marker_image(marker_id, inverted=True)
        cv2.imwrite(
            os.path.join(args.out_dir, "marker_{:03d}.png".format(marker_id)), marker_image)

    print(
        f'[*] Successfully generated {max_marker_id - min_marker_id} markers')


def generate_marker_grid():
    parser = argparse.ArgumentParser('Generate Marker Images')
    parser.add_argument('out_dir', metavar='OUTPUT_DIR', type=str)
    parser.add_argument('--num-cols', type=int, required=False, default=14,
                        dest='num_cols', help=('Number of marker columns, '
                                               'defaults to 14'))
    parser.add_argument('--num-rows', type=int, required=False, default=10,
                        dest='num_rows', help=('Number of marker rows, '
                                               'defaults to 10'))
    parser.add_argument('--marker-size', type=int, required=False, default=15,
                        dest='marker_size', help=('Marker size in millimeter, '
                                                  'defaults to 15'))
    parser.add_argument('--marker-gap', type=int, required=False, default=5,
                        dest='marker_gap', help=('Marker gap in millimeter, '
                                                 'defaults to 5'))
    args = parser.parse_args()

    grid = MarkerGrid(
        num_cols=args.num_cols,
        num_rows=args.num_rows,
        size=args.marker_size,
        gap=(args.marker_gap, args.marker_gap))

    svg_string, ids, positions = Marker.generate_marker_grid(
        grid, Marker.SHEET_SIZE_A4_LANDSCAPE)

    grid.marker_positions = positions
    grid.marker_ids = ids

    basename = 'grid_cols_{:d}_rows_{:d}_size_{:d}'.format(
        grid.num_cols, grid.num_rows, grid.marker_size)

    # Save the grid SVG image
    with open(os.path.join(args.out_dir, basename + '.svg'), 'w') as f:
        f.write(svg_string)

    # Save the grid definition
    grid.save_to_file(os.path.join(args.out_dir, basename + '.json'))

    print(
        f'[*] Successfully generated marker grid image')
