import json
from typing import Tuple

import svgwrite

from .marker import Marker
from .hamming_codes import HammingCodes


class MarkerGrid:
    """
    A marker grid
    """

    KEY_NUM_COLS = 'num-cols'
    KEY_NUM_ROWS = 'num-rows'
    KEY_MARKER_SIZE = 'marker-size'
    KEY_MARKER_GAP = 'marker-gap'
    KEY_MARKER_IDS = 'marker-ids'
    KEY_MARKER_POSITIONS = 'marker-positions'
    KEY_MARKER_START_ID = 'start-id'

    def __init__(self, num_cols=0, num_rows=0, ids=(), positions=(),
                 size=0, gap=(0, 0), start_id=1):
        """
        Initializes a marker grid

        :param num_cols: The number of marker columns
        :param num_rows: The number of marker rows
        :param ids: List of marker IDs
        :param positions: List of marker positions as a list of
                          (x, y) tuples in mm
        :param size: The marker size as a tuple of (width, height)
                     in mm
        :param gap: The gaps between the markers as a tuple of
                    (gap_x, gap_y) in mm
        :param start_id: The ID of the first marker
        """
        self.marker_ids = ids
        self.marker_positions = positions
        self.marker_size = size
        self.marker_gap = gap
        self.num_rows = num_rows
        self.num_cols = num_cols
        self.start_id = start_id

    # Common paper sheet sizes
    SHEET_SIZE_A3 = (297, 420)
    SHEET_SIZE_A3_LANDSCAPE = (420, 297)
    SHEET_SIZE_A4 = (210, 297)
    SHEET_SIZE_A4_LANDSCAPE = (297, 210)

    def generate_marker_grid_image(self, sheet_size=SHEET_SIZE_A3_LANDSCAPE):
        """
        Generates a rectangular image marker grid as SVG.

        :param grid: The marker grid definition
        :param sheet_size: The output sheet size as tuple of (width, height) in mm.
                           For common sheet sizes have a look at the SHEET_SIZE_...
                           constants.
        :return: A tuple of (marker_grid_svg_string, marker_ids, marker_positions)
        """

        if self.num_cols * self.num_rows > 256:
            raise ValueError("")

        # Calculate the offsets to center the grid on the sheet
        grid_width = (self.num_cols * self.marker_size +
                      (self.num_cols - 1) * self.marker_gap[0])
        grid_height = (self.num_rows * self.marker_size +
                       (self.num_rows - 1) * self.marker_gap[1])

        offset_x = 0.5 * (sheet_size[0] - grid_width)
        offset_y = 0.5 * (sheet_size[1] - grid_height)

        sheet_size_mm = (str(sheet_size[0]) + 'mm',
                         str(sheet_size[1]) + 'mm')
        dwg = svgwrite.Drawing(
            'marker_grid.svg', size=sheet_size_mm, profile='tiny')
        dwg.viewbox(0, 0, sheet_size[0], sheet_size[1])

        marker_positions = []
        marker_ids = []
        marker_id = self.start_id
        # Generate the markers
        for row in range(self.num_rows):
            for col in range(self.num_cols):
                marker_pos = (offset_x + col * (self.marker_size + self.marker_gap[0]) + 0.5 * self.marker_size,
                              offset_y + row * (self.marker_size + self.marker_gap[1]) + 0.5 * self.marker_size)
                marker_pos_grid = (
                    marker_pos[0], sheet_size[1] - marker_pos[1])
                dwg.add(self._generate_svg_marker(dwg=dwg,
                                                  marker_id=marker_id,
                                                  marker_size=self.marker_size,
                                                  marker_pos=marker_pos_grid))
                marker_positions.append(marker_pos)
                marker_ids.append(marker_id)
                marker_id += 1

        # Generate coordinate system arrows
        arrow_size = 5
        p_x = (offset_x + arrow_size, sheet_size[1] - offset_y * 0.5)
        x_arrow = self._generate_svg_arrow(
            dwg, p_x, rotation=0, size=arrow_size)
        dwg.add(x_arrow)

        p_y = (offset_x * 0.5, sheet_size[1] - offset_y - arrow_size)
        y_arrow = self._generate_svg_arrow(
            dwg, p_y, rotation=-90, size=arrow_size)
        dwg.add(y_arrow)

        return dwg.tostring(), marker_ids, marker_positions

    @classmethod
    def _generate_svg_arrow(cls, dwg: svgwrite.Drawing, pos=(0, 0), size=5, rotation=0):
        arrow_path = dwg.path(d="M0,0 L-1,-0.25 L-1,0.25 z")
        arrow_path.fill(color="black")
        arrow_path.translate(pos[0], pos[1])
        arrow_path.scale(size)
        arrow_path.rotate(rotation)

        return arrow_path

    @classmethod
    def _generate_svg_marker(cls, dwg: svgwrite.Drawing, marker_id: int,
                             marker_pos: Tuple[float, float],
                             marker_size: float = 10, inverted=False):

        # Create a group that holds all marker fields
        marker_group = dwg.g()

        # Generate the marker border
        for i in range(Marker.MARKER_SIZE):
            marker_group.add(cls._generate_svg_marker_bit(
                dwg, i, 0, False, inverted))
        for i in range(Marker.MARKER_SIZE):
            marker_group.add(cls._generate_svg_marker_bit(
                dwg, i, Marker.MARKER_SIZE - 1, False, inverted))
        for i in range(1, Marker.MARKER_SIZE - 1):
            marker_group.add(cls._generate_svg_marker_bit(
                dwg, 0, i, False, inverted))
        for i in range(1, Marker.MARKER_SIZE - 1):
            marker_group.add(cls._generate_svg_marker_bit(
                dwg, Marker.MARKER_SIZE - 1, i, False, inverted))

        # Set the orientation bits
        for bit_pos in [(1, 1), (1, 4), (4, 1)]:
            marker_group.add(cls._generate_svg_marker_bit(
                dwg, bit_pos[0], bit_pos[1], True, inverted))
        marker_group.add(cls._generate_svg_marker_bit(
            dwg, 4, 4, False, inverted))

        # Set Hamming code bits
        marker_encoded = HammingCodes.hamming_code_n15(marker_id)
        for i in range(12):
            bit_value = marker_encoded & (1 << i)
            bit_pos = Marker.bit_pos_to_marker_pos(i)
            marker_group.add(cls._generate_svg_marker_bit(
                dwg, bit_pos[1], bit_pos[0], bit_value, inverted))

        # Translate and scale the marker
        marker_group.translate(marker_pos[0], marker_pos[1])
        marker_group.scale(marker_size / Marker.MARKER_SIZE)

        return marker_group

    @classmethod
    def _generate_svg_marker_bit(cls, dwg: svgwrite.Drawing, i: int, j: int,
                                 value: bool, inverted=False):
        bit_rect = dwg.rect(insert=(-0.5 * Marker.MARKER_SIZE + i,
                                    -0.5 * Marker.MARKER_SIZE + j),
                            size=(1, 1))
        bit_rect.fill(
            color="white" if value and not inverted or not value and inverted else "black")
        return bit_rect

    @classmethod
    def load_from_json(cls, filename: str):
        """
        Load a marker grid from a mesh definition JSON file
        :param filename:
        :return:
        """
        with open(filename, 'r') as f:
            raw_json = f.read()

        json_dict = json.loads(raw_json)

        # TODO Implement schema checks here

        grid = MarkerGrid()
        grid.num_cols = json_dict[MarkerGrid.KEY_NUM_COLS]
        grid.num_rows = json_dict[MarkerGrid.KEY_NUM_ROWS]
        grid.marker_size = json_dict[MarkerGrid.KEY_MARKER_SIZE]
        grid.marker_gap = json_dict[MarkerGrid.KEY_MARKER_GAP]
        grid.marker_ids = json_dict[MarkerGrid.KEY_MARKER_IDS]
        grid.marker_positions = json_dict[MarkerGrid.KEY_MARKER_POSITIONS]
        grid.start_id = json_dict[MarkerGrid.KEY_MARKER_START_ID]

        return grid

    def save_to_file(self, filename: str):
        """
        Saves the marker grid definition to a JSON file
        :param filename: The file where the marker grid definition will be saved to
        """
        with open(filename, 'w') as f:
            f.write(json.dumps({
                MarkerGrid.KEY_NUM_COLS: self.num_cols,
                MarkerGrid.KEY_NUM_ROWS: self.num_rows,
                MarkerGrid.KEY_MARKER_SIZE: self.marker_size,
                MarkerGrid.KEY_MARKER_GAP: self.marker_gap,
                MarkerGrid.KEY_MARKER_IDS: self.marker_ids,
                MarkerGrid.KEY_MARKER_POSITIONS: self.marker_positions,
                MarkerGrid.KEY_MARKER_START_ID: self.start_id
            }))
