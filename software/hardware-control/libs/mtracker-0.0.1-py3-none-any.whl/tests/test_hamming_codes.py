import unittest
from marker_tracking import HammingCodes


class TestHammingCodes(unittest.TestCase):

    def test_active_bits_should_throw_error_on_zero_num_bits(self):
        self.assertRaises(
            ValueError, HammingCodes.active_bits, data=0, num_bits=0)

    def test_active_bits_should_throw_error_on_negative_num_bits(self):
        self.assertRaises(
            ValueError, HammingCodes.active_bits, data=0, num_bits=-1)

    def test_zero_active_bits_0(self):
        self.assertEqual(0, HammingCodes.active_bits(0, 32))

    def test_zero_active_bits_127(self):
        self.assertEqual(7, HammingCodes.active_bits(127, 32))

    def test_error_in_bit_pos(self):
        data = 176
        code = HammingCodes.hamming_code_n15(data)

        for i in range(15):
            pos = i + 1
            defect_code = code ^ (1 << i)

            detected_error_pos = HammingCodes.error_in_bit_pos(defect_code)
            self.assertEqual(pos, detected_error_pos)


if __name__ == '__main__':
    unittest.main()
